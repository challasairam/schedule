package com.cg.scheduleplan.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.scheduleplan.bean.FacultyBean;
import com.cg.scheduleplan.service.IScheduleService;

@Controller
public class ScheduleController {

	@Autowired
	IScheduleService service;

	@RequestMapping("/index")
	public String homepage() {
		String view = null;
		view = "HomePage";
		return view;
	}

	@RequestMapping(value = "/fillForms")
	public ModelAndView fillForm() {

		ModelAndView view = new ModelAndView("fillForm", "plan",
				new FacultyBean());
		List<String> period = new ArrayList<>();
		period.add("Select");
		period.add("Maths");
		period.add("Physics");
		period.add("Chemistry");
		period.add("Biology");
		period.add("English");
		view.addObject("list", period);
		return view;

	}

	@RequestMapping(value = "registered", method = RequestMethod.POST)
	public ModelAndView successfulCreation(
			@ModelAttribute("plan") @Valid FacultyBean bean,
			BindingResult result) {
		ModelAndView view = null;
		if (result.hasErrors()) {

			view = new ModelAndView("fillForm");
			List<String> period = new ArrayList<>();
			period.add("Select");
			period.add("Maths");
			period.add("Physics");
			period.add("Chemistry");
			period.add("Biology");
			period.add("English");
			view.addObject("list", period);
		} else {
			FacultyBean bean2=service.addDetails(bean);
			String url = "registered";
			view = new ModelAndView(url, "bean", new FacultyBean());
			view.addObject("id", bean2.getFacultyId());
		}
		return view;

	}

	@RequestMapping("/viewAll")
	public ModelAndView viewAllPlans() {
		ModelAndView view = new ModelAndView();
		ArrayList<FacultyBean> list = service.viewAllPlan();
		view.addObject("allList", list);
		view.setViewName("viewAll");
		return view;
	}

	@RequestMapping("/viewById")
	public ModelAndView viewByPlanId() {
		ModelAndView view = new ModelAndView("viewById", "tec",
				new FacultyBean());
		return view;
	}

	@RequestMapping("/viewSinglePlan")
	public ModelAndView viewSinglePlan(@RequestParam("id") Integer id) {

		ModelAndView view = new ModelAndView();
		ArrayList<FacultyBean> list = service.viewByPlanId(id);
		if (list.isEmpty()) {
			ArrayList<String> list1 = new ArrayList<>();
			list1.add("No Data found");
			view.addObject("allList", list1);
			view.setViewName("viewAll");

		} else {
			view.addObject("allList", list);
			view.setViewName("viewAll");
		}
		return view;
	}

}
