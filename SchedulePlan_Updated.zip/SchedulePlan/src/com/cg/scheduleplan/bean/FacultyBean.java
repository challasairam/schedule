package com.cg.scheduleplan.bean;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name = "faculty_master")
@NamedQueries({
		@NamedQuery(name = "viewall", query = "SELECT f FROM FacultyBean f"),
		@NamedQuery(name = "viewallbyid", query = "SELECT f FROM FacultyBean f WHERE f.facultyId = :id"), })
public class FacultyBean {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	@Column(name = "Faculty_id")
	private Integer facultyId;
	@Column(name = "Faculty_name")
	@NotEmpty(message = "please fill")
	private String fullName;
	@Transient
	private String date;
	@Column(name = "Fac_expert_in")
	@NotEmpty(message = "please fill")
	private String facultyExpertIn;
	@Column(name = "Period")
	@NotEmpty(message = "please fill")
	private String period;
	@Column(name = "Comments")
	@NotEmpty(message = "please fill")
	private String comments;
	@Column(name = "Email_id")
	@NotEmpty(message = "please fill")
	@Pattern(regexp = "[A-Za-z0-9]+[@][A-Za-z]+[.][A-Za-z]{1,4}", message = "Enter valid email")
	private String mailId;
	@Column(name = "cur_date")
	private Date date1;
	
	public Date getDate1() {
		return date1;
	}

	public void setDate1(Date date1) {
		this.date1 = date1;
	}

	public Integer getFacultyId() {
		return facultyId;
	}

	public void setFacultyId(Integer facultyId) {
		this.facultyId = facultyId;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getFacultyExpertIn() {
		return facultyExpertIn;
	}

	public void setFacultyExpertIn(String facultyExpertIn) {
		this.facultyExpertIn = facultyExpertIn;
	}

	public String getPeriod() {
		return period;
	}

	public void setPeriod(String period) {
		this.period = period;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getMailId() {
		return mailId;
	}

	public void setMailId(String mailId) {
		this.mailId = mailId;
	}

	public FacultyBean() {

	}

	@Override
	public String toString() {
		return facultyId+" "+fullName + " " + facultyExpertIn + " " + date1 + " " + period
				+ " " + comments + " " + mailId;
	}

}
