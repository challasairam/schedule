package com.cg.scheduleplan.dao;

import java.text.SimpleDateFormat;
import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.scheduleplan.bean.FacultyBean;

@Repository
@Transactional
public class ScheduleDaoImpl implements IScheduleDao {

	@PersistenceContext
	EntityManager entityManager;

	@Override
	public FacultyBean addDetails(FacultyBean bean) {

		try
		{
		String currentDate=bean.getDate();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		java.util.Date date = sdf.parse(currentDate);
		java.sql.Date sqlCurrentDate = new java.sql.Date(date.getTime()); 
		bean.setDate1(sqlCurrentDate);
		entityManager.persist(bean);
		entityManager.flush();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	
		
		return bean;
	}

	@Override
	public ArrayList<FacultyBean> viewAllPlan() {
		Query query = entityManager.createNamedQuery("viewall");
		@SuppressWarnings("unchecked")
		ArrayList<FacultyBean> list = (ArrayList<FacultyBean>) query
				.getResultList();
		
		return list;
	}

	@Override
	public ArrayList<FacultyBean> viewByPlanId(Integer id) {
		Query query = entityManager.createNamedQuery("viewallbyid");
		@SuppressWarnings("unchecked")
		ArrayList<FacultyBean> list = (ArrayList<FacultyBean>) query
				.setParameter("id", id).getResultList();
		return list;
	}
}
