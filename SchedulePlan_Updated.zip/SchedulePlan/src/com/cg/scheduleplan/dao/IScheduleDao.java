package com.cg.scheduleplan.dao;

import java.util.ArrayList;

import com.cg.scheduleplan.bean.FacultyBean;

public interface IScheduleDao {
	public FacultyBean addDetails(FacultyBean bean);
	public ArrayList<FacultyBean> viewAllPlan();
	public ArrayList<FacultyBean> viewByPlanId(Integer id);
}
