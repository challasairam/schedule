package com.cg.scheduleplan.service;

import java.util.ArrayList;

import com.cg.scheduleplan.bean.FacultyBean;

public interface IScheduleService {
public FacultyBean addDetails(FacultyBean bean);
public ArrayList<FacultyBean> viewAllPlan();
public ArrayList<FacultyBean> viewByPlanId(Integer id);
}
