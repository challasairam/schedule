package com.cg.scheduleplan.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.scheduleplan.bean.FacultyBean;
import com.cg.scheduleplan.dao.IScheduleDao;

@Service
public class ScheduleServiceImpl implements IScheduleService {

	@Autowired
	IScheduleDao dao;

	@Override
	public FacultyBean addDetails(FacultyBean bean) {

		return dao.addDetails(bean);
	}

	@Override
	public ArrayList<FacultyBean> viewAllPlan() {
		return dao.viewAllPlan();
	}

	@Override
	public ArrayList<FacultyBean> viewByPlanId(Integer id) {
		return dao.viewByPlanId(id);
	}

}
