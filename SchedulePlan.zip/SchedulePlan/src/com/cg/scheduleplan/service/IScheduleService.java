package com.cg.scheduleplan.service;

import com.cg.scheduleplan.bean.FacultyBean;

public interface IScheduleService {
public boolean addDetails(FacultyBean bean);
}
