package com.cg.scheduleplan.bean;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name = "faculty_master")
public class FacultyBean {

	/*@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "faculty_id")
	private Integer facultyId;*/
	@Column(name = "full_name")
	@NotEmpty(message = "Cannot be empty")
	private String fullName;
	@Column(name = "date")
	private String date;
	@Column(name = "faculty_expert_in")
	@NotEmpty(message = "Cannot be empty")
	private String facultyExpertIn;
	@Column(name = "period")
	@NotEmpty(message = "Cannot be empty")
	private String period;
	@Column(name = "comments")
	@NotEmpty(message = "Cannot be empty")
	private String comments;
	@Column(name = "mail_id")
	@NotEmpty(message = "Cannot be empty")
	@Pattern(regexp = "[A-Za-z0-9]+[@][A-Za-z]+[.]+[A-Za-z]{2,4}", message = "Not a valid email: sample mail:xxx@xxx.xxxx")
	private String mailId;

/*	public Integer getFacultyId() {
		return facultyId;
	}

	public void setFacultyId(Integer facultyId) {
		this.facultyId = facultyId;
	}
*/
	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getFacultyExpertIn() {
		return facultyExpertIn;
	}

	public void setFacultyExpertIn(String facultyExpertIn) {
		this.facultyExpertIn = facultyExpertIn;
	}

	public String getPeriod() {
		return period;
	}

	public void setPeriod(String period) {
		this.period = period;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getMailId() {
		return mailId;
	}

	public void setMailId(String mailId) {
		this.mailId = mailId;
	}

	public FacultyBean() {

	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return /*facultyId+*/" "+fullName+" "+date+" "+period+" "+comments+" "+mailId;
	}
}
