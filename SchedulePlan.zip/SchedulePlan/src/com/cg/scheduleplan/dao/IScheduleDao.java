package com.cg.scheduleplan.dao;

import com.cg.scheduleplan.bean.FacultyBean;

public interface IScheduleDao {
	public boolean addDetails(FacultyBean bean);

}
