package com.cg.scheduleplan.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cg.scheduleplan.bean.FacultyBean;

@Repository
@Transactional
public class ScheduleDaoImpl implements IScheduleDao {

	
	@PersistenceContext
	EntityManager entitymanager;
	@Override
	public boolean addDetails(FacultyBean bean) {

		System.out.println("In Dao");
		System.out.println(bean);
		entitymanager.persist(bean);
		entitymanager.flush();
		System.out.println("persisted");
		return false;
	}

}
